import React from "react";

export default function Home(props) {
  return <div>Home</div>;
}
